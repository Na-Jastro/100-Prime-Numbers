﻿using System;

namespace Justice_Ngwenya_100_Prime_Numbers
{
    class Program
    {
        //Get 100 Prime Numbers
        static void Main(string[] args)
        {
            int startNumber = 1;
            int endNumber = 100;
            int  i, add;

            Console.WriteLine("100 Prime Numbers");
            for (int x = startNumber; x <= endNumber; x++)
            {
                add = 0;

                for (i = 2; i <= x / 2; i++)
                {
                    if (x % i == 0)
                    {
                        add++;
                        break;
                    }
                }
                if (add == 0 && x != 1)
                    Console.Write(" {0}\n", x);
            }
            Console.ReadLine();
        }
    }
}
